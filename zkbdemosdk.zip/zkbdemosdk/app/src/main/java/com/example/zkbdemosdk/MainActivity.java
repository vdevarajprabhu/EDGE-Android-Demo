package com.example.zkbdemosdk;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.adobe.marketing.mobile.AdobeCallback;
import com.adobe.marketing.mobile.Assurance;
import com.adobe.marketing.mobile.Edge;
import com.adobe.marketing.mobile.Lifecycle;
import com.adobe.marketing.mobile.LoggingMode;
import com.adobe.marketing.mobile.MobileCore;
import com.adobe.marketing.mobile.Signal;
import com.adobe.marketing.mobile.UserProfile;
import com.adobe.marketing.mobile.edge.consent.Consent;
import com.adobe.marketing.mobile.edge.identity.Identity;
import com.adobe.marketing.mobile.Analytics;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.adobe.marketing.mobile.Target;
import com.adobe.marketing.mobile.target.TargetParameters;
import com.adobe.marketing.mobile.target.TargetRequest;

import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    public String EcidForAPI = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MobileCore.setApplication(this.getApplication());
        MobileCore.setLogLevel(LoggingMode.DEBUG);

        List extensions = Arrays.asList(
                com.adobe.marketing.mobile.Identity.EXTENSION,
                com.adobe.marketing.mobile.edge.identity.Identity.EXTENSION,
                Lifecycle.EXTENSION,
                Signal.EXTENSION,
                UserProfile.EXTENSION,
                Edge.EXTENSION,
                Assurance.EXTENSION,
                Consent.EXTENSION,
                Target.EXTENSION,
                Analytics.EXTENSION
        );

        MobileCore.registerExtensions(extensions, new AdobeCallback () {
            @Override
            public void call(Object o) {
                MobileCore.configureWithAppID("2fd35f2549c1/3e482a7d2029/launch-a28e03141570-development");
            }
        });

        Identity.getExperienceCloudId(new AdobeCallback<String>() {
            @Override
            public void call(String ecid) {
                //Handle the ID returned here
                TextView adobeECID = (TextView) findViewById(R.id.txtECID);
                EcidForAPI = ecid;
                adobeECID.setText(ecid);
                Log.d("EcidForAPI",EcidForAPI);
            }
        });

        String extensionVersion = Identity.extensionVersion();
        System.out.println("Identity.extensionVersion " + extensionVersion );

        setContentView(R.layout.activity_main);

        //Assurance debug
        final Button btnConnectToAssuranceSession = findViewById(R.id.btnConnectToAssuranceSession);
        final EditText txtAssuranceSessionURL = findViewById(R.id.txtAssuranceSessionURL);
        // start session
        btnConnectToAssuranceSession.setOnClickListener(v -> Assurance.startSession(txtAssuranceSessionURL.getText().toString()));


        Map<String, String> mboxParameters1 = new HashMap<>();
        mboxParameters1.put("status", "platinum");

        TargetParameters parameters1 = new TargetParameters.Builder().parameters(mboxParameters1).build();

        TargetRequest request1 = new TargetRequest("zkb_demo", parameters1, "defaultContent1",
                new AdobeCallback<String>() {
                    @Override
                    public void call(String callbackData) {
                        TextView targetTextView = (TextView) findViewById(R.id.tt_text_view);
                        // do something with target content.
                        if (callbackData.equals("defaultContent1")) {
                            System.out.println("Retrieve location content default content received: " + callbackData + " for mbox zkb_demo ");
                        } else {
                            try {
                                JSONObject callbackDataJson = new JSONObject(callbackData);
                                String targetContent = callbackDataJson.getString("title");
                                Log.d("Retrieve location content ---- ", targetContent);
                                System.out.println("Retrieve location content received: " + targetContent + " for mbox zkb_demo ");
                                targetTextView.setText(targetContent);
                            } catch (Throwable tx) {
                                Log.e("My App", "Could not parse malformed JSON: \"" + callbackData + "\"");
                            }
                        }
                    }
                }
        );

        // Creating Array of Request Objects
        List<TargetRequest> locationRequests = new ArrayList<>();
        locationRequests.add(request1);

        // Define the profile parameters map.
        Map<String, String> profileParameters1 = new HashMap<>();
        profileParameters1.put("ageGroup", "20-32");

        TargetParameters parameters = new TargetParameters.Builder().profileParameters(profileParameters1).build();

        // Call the targetRetrieveLocationContent API.
        Target.retrieveLocationContent(locationRequests, parameters);
    }

    @Override
    public void onResume() {
        super.onResume();
        MobileCore.setApplication(getApplication());
        MobileCore.lifecycleStart(null);
    }

    @Override
    public void onPause() {
        super.onPause();
        MobileCore.lifecyclePause();
    }
}